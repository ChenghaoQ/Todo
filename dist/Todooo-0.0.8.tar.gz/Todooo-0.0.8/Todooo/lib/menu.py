#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def main_menu():
	print("""* * * * Welcome come to TODO * * * *
	1. New user
	2. User Login
	3. About
	4. Help
	5. Exit
	Please Select: """,end='')

def after_login(username):
	print(""" * * * *Welcome back! %s * * * *
	1. Check Your list
	2. Modify your account
	3. Account Delete
	4. Back to Main Menu
	Please Select: """%username)


